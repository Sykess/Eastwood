
public interface BallListener
{
    public boolean ballMoved(BallEvent e);
    public int sideHit(BallEvent e);
}
