#ifndef MYSQRT_H
#define MYSQRT_H

#define P0 0.2549729994354
#define P1 1.172251620351
#define P2 0.6720680317089
#define P3 0.3075057498669
#define P4 0.0626624251406
#define COMPUTE 0.8888

float mySqrt(float f);

#endif
